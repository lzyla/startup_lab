from django.contrib import admin
from .models import Character

admin.site.register(Character)